from Vlakno import Vlakno
import math
from Tkinter import *


class Predajnik:

   def __init__(self, redni_broj, flag2, izlazna, ulazna, valna):
        self.redni_broj = redni_broj
        if flag2 == 1:
             root = Tk()

             label4 = Label(root, text=" Predajnik " + str(self.redni_broj + 1))
             label4.pack()

             frame = Frame(root)
             frame.pack()



             def quit(root):
                  root.destroy()

             label = Label(root, text="Ulazna snaga [mW]:")
             label.pack(side = TOP)

             var = StringVar()
             ent = Entry(root, textvariable=var, width=7)
             ent.pack(anchor=CENTER)

             label2 = Label(root, text="Izlazna snaga [mW]:")
             label2.pack(side = TOP)

             var2 = StringVar()
             ent1 = Entry(root, textvariable=var2, width=7)
             ent1.pack(anchor=CENTER)

             label3 = Label(root, text="Valna duljina [nm]:")
             label3.pack()

             var3 = StringVar()
             ent2 = Entry(root, textvariable=var3, width=7)
             ent2.pack(anchor=CENTER)

             label = Label(root)
             label.pack()

             button = Button(root, text="Dalje", command=lambda root=root: quit(root))
             button.pack(anchor=CENTER)

             root.mainloop()


             self.izlazna_snaga = int(float(var2.get()))
             self.ulazna_snaga = int(float(var.get()))
             #self.raspon = input("Raspon podesavanja = ")
             #self.vrijeme = input("Vrijeme podesavanja = ")
             self.valna_duljina = int(float(var3.get()))
             print

        else:
             self.izlazna_snaga = izlazna
             self.ulazna_snaga = ulazna
             # self.raspon = input("Raspon podesavanja = ")
             # self.vrijeme = input("Vrijeme podesavanja = ")
             self.valna_duljina = valna

        vlakno = Vlakno()
        self.loss = 10*math.log10(float(self.izlazna_snaga) / float(self.ulazna_snaga))
        self.loss = self.loss - vlakno.duljina * vlakno.prigusenje - 2 * vlakno.konektor


