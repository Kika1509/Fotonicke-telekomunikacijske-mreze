from Tkinter import *
from PIL import ImageTk, Image


class Vlakno:

    default = 1
    var0 = 10           #signal???????????????
    var1 = 10           #duljina
    var2 = 10           #prigusenje
    var3 = 10           #NA
    var4 = 10           #konektor
    var5 = 10           #spoj


    def __init__(self):
        if self.default == 1: #U OVOM SLUCAJU KORISNIK NA POCETKU DEFINIRA UNIVERZALNO VLAKNO KOJE, STAVLJA SE DRUKCIJA DEFAULT VRIJEDNOST default

            #Vlakno.var0 =


            root = Tk()

            def quit(root):
                root.destroy()

            root.attributes("-fullscreen", True)
            left1 = Frame(root)
            left1.pack(side=LEFT)
            bottom = Frame(root)

            bottom.pack(side=BOTTOM)

            img = ImageTk.PhotoImage(Image.open("src/fibers.jpg"))
            panel = Label(root, image=img)
            panel.pack(fill="both", expand="yes")

            frame = Frame(root)
            frame.pack

            def close(root):
                root.destroy()
                exit()

            e = Button(root, text="Exit", font=('Console', 20), command=lambda: close(root))
            e.place(rely=0, relx=1.0, x=0, y=0, anchor=NE)
            label1 = Label(root, text="Univerzalno vlakno")
            label1.pack(in_=left1)

            label12 = Label(root, text="duljina vlakna [km]")
            label12.pack(in_=left1)

            vr1 = StringVar()
            ent = Entry(root, textvariable=vr1, width=7)
            ent.pack(in_=left1)

            label13 = Label(root, text="koeficijent prigusenja")
            label13.pack(in_=left1)

            vr2 = StringVar()
            ent1 = Entry(root, textvariable=vr2, width=7)
            ent1.pack(in_=left1)

            label14 = Label(root, text="numericka apertura")
            label14.pack(in_=left1)

            vr3 = StringVar()
            ent2 = Entry(root, textvariable=vr3, width=7)
            ent2.pack(in_=left1)

            label15 = Label(root, text="gubitak na konektoru [dB]")
            label15.pack(in_=left1)

            vr4 = StringVar()
            ent3 = Entry(root, textvariable=vr4, width=7)
            ent3.pack(in_=left1)

            label16 = Label(root, text="gubitak na fizickom sloju [dB]")
            label16.pack(in_=left1)

            vr5 = StringVar()
            ent4 = Entry(root, textvariable=vr5, width=7)
            ent4.pack(in_=left1)

            button2 = Button(root, text="Dalje", font=('Console', 20),command=lambda root=root: quit(root))
            button2.pack()

            root.mainloop()

            Vlakno.var1 = int(float(vr1.get()))  #stavit slajder
            Vlakno.var2 = int(float(vr2.get()))         #stavit slajder
            Vlakno.var3 = int(float(vr3.get()))            #stavit slajder
            Vlakno.var4 = int(float(vr4.get()))              #stavit slajder
            Vlakno.var5 = int(float(vr5.get()))     #stavit slajder
            Vlakno.default = 2


        elif self.default == 0: #AKO JE 0 ONDA CE KORISNIK SVAKI PUT UNOSITI VRIJEDNOSTI SVAKOG VLAKNA
            #self.signal = signal

            root = Tk()

            def quit(root):
                root.destroy()



            frame = Frame(root)
            frame.pack

            label1 = Label(root, text="Vlakno")
            label1.pack()

            label12 = Label(root, text="duljina vlakna [km]")
            label12.pack()

            vr1 = StringVar()
            ent = Entry(root, textvariable=vr1, width=7)
            ent.pack(anchor=CENTER)

            label13 = Label(root, text="koeficijent prigusenja")
            label13.pack()

            vr2 = StringVar()
            ent1 = Entry(root, textvariable=vr2, width=7)
            ent1.pack(anchor=CENTER)

            label14 = Label(root, text="numericka apertura")
            label14.pack()

            vr3 = StringVar()
            ent2 = Entry(root, textvariable=vr3, width=7)
            ent2.pack(anchor=CENTER)

            label15 = Label(root, text="gubitak na konektoru [dB]")
            label15.pack()

            vr4 = StringVar()
            ent3 = Entry(root, textvariable=vr4, width=7)
            ent3.pack(anchor=CENTER)

            label16 = Label(root, text="gubitak na fizickom sloju [dB]")
            label16.pack()

            button2 = Button(root, text="Dalje", command=lambda root=root: quit(root))
            button2.pack(anchor=CENTER)

            vr5 = StringVar()
            ent4 = Entry(root, textvariable=vr5, width=7)
            ent4.pack(anchor=CENTER)

            root.mainloop()

            self.duljina =int(float(vr1.get()))          #stavit slajder
            self.prigusenje =int(float(vr2.get()))    #stavit slajder
            self.NA = int(float(vr3.get()))              #stavit slajder
            self.konektor = int(float(vr4.get()))            #stavit slajder
            self.spoj = int(float(vr5.get()))      #stavit slajder
            #print

        if self.default == 2:
            #self.signal = Vlakno.var0
            self.duljina = Vlakno.var1
            self.prigusenje = Vlakno.var2
            self.NA = Vlakno.var3
            self.konektor = Vlakno.var4
            self.spoj = Vlakno.var5

