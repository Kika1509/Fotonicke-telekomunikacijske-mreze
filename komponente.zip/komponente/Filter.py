from Vlakno import Vlakno
from Tkinter import *
from PIL import ImageTk, Image


class Filter:

    def __init__(self, signals, br, list2, list3, snaga):

        root = Tk()
        left = Frame(root)
        right = Frame(root)
        right.pack(side=RIGHT)
        left.pack(side=LEFT)
        root.attributes("-fullscreen", True)

        def quit(root):
            root.destroy()

        left1 = Frame(root)
        left1.pack(side=LEFT)
        bottom = Frame(root)

        def close(root):
            root.destroy()
            exit()

        e = Button(root, text="Exit", font=('Console', 20), command=lambda: close(root))
        e.place(rely=0, relx=1.0, x=0, y=0, anchor=NE)
        bottom.pack(side=BOTTOM)
        if br == 1:
            img = ImageTk.PhotoImage(Image.open("src/filter1.jpg"))
        elif br == 2:
            img = ImageTk.PhotoImage(Image.open("src/filter2.jpg"))
        elif br == 3:
            img = ImageTk.PhotoImage(Image.open("src/filter3.jpg"))
        elif br == 4:
            img = ImageTk.PhotoImage(Image.open("src/filter4.jpg"))
        panel = Label(root, image=img)
        panel.pack(fill="both", expand="yes")



        label1 = Label(root, text=str(signals) + "\nSredisnja valna duljina [nm]")
        label1.pack(in_=left)

        var1 = StringVar()
        ent = Entry(root, textvariable=var1, width=7)
        ent.pack(in_=left)

        label2 = Label(root, text="Sirina pojasa [nm]")
        label2.pack(in_=left)

        var2 = StringVar()
        ent2 = Entry(root, textvariable=var2, width=7)
        ent2.pack(in_=left)

        button = Button(root, text="Dalje", command=lambda root=root: quit(root))
        button.pack(in_=left)

        broj = ""
        if isinstance(list2, int):
            broj = "\n" + str(list2) + "[nm]"
        else:
            for i in range(0, len(list2)):
                broj += "\n" + str(list2[i]) + "[nm]"

        broj2 = ""
        if isinstance(list3, int):
            broj2 = "\n" + str(list3) + "[nm]"
        else:
            for i in range(0, len(list3)):
                broj2 += "\n" + str(list3[i]) + "[nm]"

        label8 = Label(root, text="Valne duljine na ulazu u pojacalo:" + broj)
        label8.pack(in_=right)

        label8 = Label(root, text="\nValne duljine prijemnika:" + broj2)
        label8.pack(in_=right)

        label8 = Label(root, text="\nUlazna snaga:" + str(snaga) + "[dB]")
        label8.pack(in_=right)


        root.mainloop()

        self.sredisnja = float (var1.get())
        self.signals = signals

        #self.vrsna = input("Unesite vrsnu valnu duljinu: ")

        self.sirina = float(var2.get())
        self.gubitak = 2            #takoder neka konstanta
        self.flag2 = 1


        flag = 0
        for i in range (0, len(signals)):
            if (signals[i]>(self.sredisnja-self.sirina) and signals[i]< (self.sredisnja+self.sirina)):
                self.izlazna = signals[i]
                flag += 1

        if flag != 1:
            print "filter nije filtrirao"
            self.izlazna = 0
            self.flag2 = 0

        vlakno = Vlakno()
        self.loss = -self.gubitak - vlakno.duljina * vlakno.prigusenje - 2 * vlakno.konektor