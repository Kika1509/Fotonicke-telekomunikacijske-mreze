from Vlakno import Vlakno
from Tkinter import *
from Predajnik import Predajnik
from PIL import ImageTk, Image

class ValniPretvornik:

    def __init__(self, list2, list3, snaga):
        root = Tk()
        left = Frame(root)

        left.pack(side=LEFT)
        right = Frame(root)
        right.pack(side=RIGHT)
        root.attributes("-fullscreen", True)

        def quit(root):
            root.destroy()

        left1 = Frame(root)
        left1.pack(side=LEFT)
        bottom = Frame(root)

        bottom.pack(side=BOTTOM)
        img = ImageTk.PhotoImage(Image.open("src/wave.jpg"))
        panel = Label(root, image=img)
        panel.pack(fill="both", expand="yes")

        label4 = Label(root, text="Valni pretvornik")
        label4.pack(in_=left)

        label = Label(root, text="Gubitak [dB]:")
        label.pack(in_=left)

        var = StringVar()
        ent = Entry(root, textvariable=var, width=7)
        ent.pack(in_=left, anchor=CENTER)

        label = Label(root, text="Nova valna duljina [nm]:")
        label.pack(in_=left)

        var1 = StringVar()
        ent1 = Entry(root, textvariable=var1, width=7)
        ent1.pack(in_=left, anchor=CENTER)

        def close(root):
            root.destroy()
            exit()

        e = Button(root, text="Exit", font=('Console', 20), command=lambda: close(root))
        e.place(rely=0, relx=1.0, x=0, y=0, anchor=NE)
        button = Button(root, text="Dalje", command=lambda root=root: quit(root))
        button.pack(in_=left)

        broj = ""
        if isinstance(list2, int):
            broj = "\n" + str(list2) + "[nm]"
        else:
            for i in range(0, len(list2)):
                broj += "\n" + str(list2[i]) + "[nm]"

        broj2 = ""
        if isinstance(list3, int):
            broj2 = "\n" + str(list3) + "[nm]"
        else:
            for i in range(0, len(list3)):
                broj2 += "\n" + str(list3[i]) + "[nm]"

        label8 = Label(root, text="Valne duljine na ulazu u pojacalo:" + broj)
        label8.pack(in_=right)

        label8 = Label(root, text="\nValne duljine prijemnika:" + broj2)
        label8.pack(in_=right)

        label8 = Label(root, text="\nUlazna snaga:" + str(snaga) + "[dB]")
        label8.pack(in_=right)


        root.mainloop()

        self.nova_valna_duljina = int(float( var.get()))
        self.gubitak = float(var1.get())
        vlakno = Vlakno()
        self.loss = - self.gubitak - vlakno.duljina * vlakno.prigusenje - 2 * vlakno.konektor
