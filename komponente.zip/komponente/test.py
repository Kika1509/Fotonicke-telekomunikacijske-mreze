from Vlakno import Vlakno


#OVDJE NETREBATE NISTA STAVLJATI OVO JE NEKI MOJ TEST!!!!!!!!!!!!!!!!!!

class Spreznik:
   #Common base class
   empCount = 0

   def __init__(self, list):
        self.gubitak_sprezanja = input("Unesite snagu u mW za predajnik ")
        self.gubitak_rasprezanja = input("Unesite snagu u mW za predajnik ")
        self.cx = input("Unesite snagu u mW za predajnik ")
        self.vrijeme = input("Unesite snagu u mW za predajnik ")
        #self.vlakno = Vlakno (1, input("Unesite duljinu vlakna od predajnika " + str(redni_broj) + " do multipleksera: "))
