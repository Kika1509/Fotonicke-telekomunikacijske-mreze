import os
import sys
import numpy as np
from Filter import Filter
from Mux import Mux
from Predajnik import Predajnik
from Vlakno import  Vlakno
from OptickoPojacalo import OptickoPojacalo
from Prijemnik import Prijemnik
from DeMux import DeMux
from Raspreznik import Raspreznik
from ValniPretvornik import ValniPretvornik
from AddDropMux import AddDropMux
from Spreznik import Spreznik
from Tkinter import *
from PIL import ImageTk, Image


br = 0


exit

#root = Tk()

def fun1():
    global br
    br = exit


def fun2():
    global br
    br = 1


def quit(root):
    root.destroy()


def combine_funcs(*funcs):
    def combined_func(*args, **kwargs):
        for f in funcs:
            f(*args, **kwargs)
    return combined_func

"""
frame = Frame(root)
frame.pack()

label1= Label(root, text= "Zelite li podesiti parametre jednog univerzalnog vlakna ili svako vlakno zasebno")
label1.pack()

button1 = Button(root, text="univerzalno vlakno", command=combine_funcs(fun1, lambda root=root:quit(root)))
button1.pack()


button2 = Button(root, text="svako vlakno zasebno", command=combine_funcs(fun2, lambda root=root:quit(root)))
button2.pack()



root.mainloop()
"""
default_vlakno = 0
#napraviti 2 tipke da korisnik odabere zeli li univerzalno vlakno ili unositi zasebno
#ako odabere univerzalno neka se pohrani vrijednost 0, ako odabere za svako onda vrijednost 1


if (default_vlakno == 0):
    Vlakno.default = 1
    defualt = Vlakno()
elif (default_vlakno == 1):
    Vlakno.default = 0


var1 = ""
var_m_s = ""
var2 = ""
var3 = ""
var4 = ""
#root = Tk()


def select():
    selection = "Broj predajnika je " + str(var1.get())
    label.config(text = selection)


def quit(root):
    root.destroy()

"""
frame = Frame(root)
frame.pack()

label = Label(root, text = "Broj predajnika")
label.pack( side =TOP)

var1 = StringVar()
ent = Entry(root, textvariable=var1, width =7)
ent.pack(anchor=CENTER)

button = Button(root, text="Unesi", command=select)
button.pack(anchor=CENTER)

label = Label(root)
label.pack()

button = Button(root, text= "Dalje", command = lambda root=root:quit(root))
button.pack(anchor=CENTER)

root.mainloop()
"""


n = 3

#mogu odmah u listu spremat snage svih predajnika ili ih preko referenca dohvacat iz objekta!!!
list_of_Predajnik_references = []
list_of_Prijemnik_references = []
list_of_Pojacalo_references = []

lista_svih_valnih_duljina = []

snage = []
snage3 = []


root = Tk()
left = Frame(root)

left.pack(side=LEFT)
root.attributes("-fullscreen", True)




def quit(root):
    root.destroy()


left1 =Frame(root)
left1.pack(side=LEFT)
bottom = Frame(root)

bottom.pack(side=BOTTOM)

label0 = Label(root,font=('Console', 25), text="Unos parametara predajnika")
label0.pack()
img = ImageTk.PhotoImage(Image.open("src/senders.jpg"))
panel = Label(root, image=img)
panel.pack(fill="both", expand="yes")

e = Button(root, text="Exit", font=('Console', 20), command=lambda: close(root))
e.place(rely=0, relx=1.0, x=0, y=0, anchor=NE)


label4 = Label(root, text="Predajnik #1")
label4.pack(in_=left)

label = Label(root, text="Ulazna snaga [mW]:")
label.pack(in_=left)

var = StringVar()
ent = Entry(root, textvariable=var, width=7)
ent.pack(in_=left,anchor=CENTER)

label2 = Label(root, text="Izlazna snaga [mW]:")
label2.pack(in_=left)

var2 = StringVar()
ent1 = Entry(root, textvariable=var2, width=7)
ent1.pack(in_=left,anchor=CENTER)

label3 = Label(root, text="Valna duljina [nm]:")
label3.pack(in_=left)

var3 = StringVar()
ent2 = Entry(root, textvariable=var3, width=7)
ent2.pack(in_=left,anchor=CENTER)

label = Label(root)
label.pack()



izlazna = []
ulazna = []
valna = []

label5 = Label(root, text="\n\nPredajnik #2")
label5.pack(in_=left)

frame = Frame(root)
frame.pack()

def quit(root):
    root.destroy()


label6 = Label(root, text="Ulazna snaga [mW]:")
label6.pack(in_=left)

var4 = StringVar()
ent3 = Entry(root, textvariable=var4, width=7)
ent3.pack(in_=left,anchor=CENTER)

label7 = Label(root, text="Izlazna snaga [mW]:")
label7.pack(in_=left)

var5 = StringVar()
ent4 = Entry(root, textvariable=var5, width=7)
ent4.pack(in_=left,anchor=CENTER)

label8 = Label(root, text="Valna duljina [nm]:")
label8.pack(in_=left)

var6 = StringVar()
ent5 = Entry(root, textvariable=var6, width=7)
ent5.pack(in_=left,anchor=CENTER)

label = Label(root)
label.pack()

#button = Button(root, text="Dalje", command=lambda root=root: quit(root))
#button.pack(anchor=CENTER)

label9 = Label(root, text="\n\nPredajnik #3")
label9.pack(in_=left)

frame = Frame(root)
frame.pack()

def quit(root):
    root.destroy()


label10 = Label(root, text="Ulazna snaga [mW]:")
label10.pack(in_=left)

var7 = StringVar()
ent6 = Entry(root, textvariable=var7, width=7)
ent6.pack(in_=left,anchor=CENTER)

label11 = Label(root, text="Izlazna snaga [mW]:")
label11.pack(in_=left)

var8 = StringVar()
ent7 = Entry(root, textvariable=var8, width=7)
ent7.pack(in_=left,anchor=CENTER)

label12 = Label(root, text="Valna duljina [nm]:")
label12.pack(in_=left)

var9 = StringVar()
ent8 = Entry(root, textvariable=var9, width=7)
ent8.pack(in_=left,anchor=CENTER)

label = Label(root)
label.pack()

button = Button(root, text="Dalje", font=('Console', 20),command=lambda root=root: quit(root))
button.pack()

def close(root):
    root.destroy()
    exit()

e = Button(root, text="Exit", font=('Console', 20), command=lambda: close(root))
e.place(rely=0, relx=1.0, x=0, y=0, anchor=NE)


root.mainloop()


izlazna = []
ulazna = []
valna = []



izlazna.append (int(float(var2.get())))
ulazna.append( int(float(var.get())))
# self.raspon = input("Raspon podesavanja = ")
# self.vrijeme = input("Vrijeme podesavanja = ")
valna.append(int(float(var3.get())))

izlazna.append (int(float(var5.get())))
ulazna.append( int(float(var4.get())))
# self.raspon = input("Raspon podesavanja = ")
# self.vrijeme = input("Vrijeme podesavanja = ")
valna.append(int(float(var6.get())))

izlazna.append (int(float(var8.get())))
ulazna.append( int(float(var7.get())))
# self.raspon = input("Raspon podesavanja = ")
# self.vrijeme = input("Vrijeme podesavanja = ")
valna.append(int(float(var9.get())))
print
print izlazna
print ulazna
print valna




for i in range (0, n):
    list_of_Predajnik_references.append(Predajnik(i,0,izlazna[i],ulazna[i],valna[i]))
    snage.append(list_of_Predajnik_references[i].loss)
    lista_svih_valnih_duljina.append(list_of_Predajnik_references[i].valna_duljina)
"""
root = Tk()


def select():
    selection = "Broj prijamnika je " + str(var2.get())
    label.config(text = selection)


def quit(root):
    root.destroy()




frame = Frame(root)
frame.pack()

label = Label(root, text = "Broj prijamnika: ")
label.pack(side=TOP)

var2 = StringVar()
ent1 = Entry(root, textvariable=var2, width =7)
ent1.pack(anchor=CENTER)

button1 = Button(root, text="Unesi", command=select)
button1.pack(anchor=CENTER)

button2 = Button(root, text= "Dalje", command = lambda root=root:quit(root))
button2.pack(anchor=CENTER)

label = Label(root)
label.pack()


root.mainloop()
"""

n = 4
all_signals = [0]*n

###################################################################
root = Tk()
left = Frame(root)

left.pack(side=LEFT)
root.attributes("-fullscreen", True)




def quit(root):
    root.destroy()


left1 =Frame(root)
left1.pack(side=LEFT)
right = Frame(root)
right.pack(side=RIGHT)


bottom = Frame(root)

bottom.pack(side=BOTTOM)
img = ImageTk.PhotoImage(Image.open("src/receivers.jpg"))
panel = Label(root, image=img)
panel.pack(fill="both", expand="yes")


label4 = Label(root, text="Prijemnik #1")
label4.pack(in_=left)

label = Label(root, text="Ulazna snaga [mW]:")
label.pack(in_=left)

var = StringVar()
ent = Entry(root, textvariable=var, width=7)
ent.pack(in_=left,anchor=CENTER)

label2 = Label(root, text="Izlazna snaga [mW]:")
label2.pack(in_=left)

var2 = StringVar()
ent1 = Entry(root, textvariable=var2, width=7)
ent1.pack(in_=left,anchor=CENTER)

label3 = Label(root, text="Valna duljina [nm]:")
label3.pack(in_=left)

var3 = StringVar()
ent2 = Entry(root, textvariable=var3, width=7)
ent2.pack(in_=left,anchor=CENTER)

label = Label(root)
label.pack()



izlazna = []
ulazna = []
valna = []

label5 = Label(root, text="\n\nPrijemnik #2")
label5.pack(in_=left)

frame = Frame(root)
frame.pack()

def quit(root):
    root.destroy()


label6 = Label(root, text="Ulazna snaga [mW]:")
label6.pack(in_=left)

var4 = StringVar()
ent3 = Entry(root, textvariable=var4, width=7)
ent3.pack(in_=left,anchor=CENTER)

label7 = Label(root, text="Izlazna snaga [mW]:")
label7.pack(in_=left)

var5 = StringVar()
ent4 = Entry(root, textvariable=var5, width=7)
ent4.pack(in_=left,anchor=CENTER)

label8 = Label(root, text="Valna duljina [nm]:")
label8.pack(in_=left)

var6 = StringVar()
ent5 = Entry(root, textvariable=var6, width=7)
ent5.pack(in_=left,anchor=CENTER)

label = Label(root)
label.pack()

#button = Button(root, text="Dalje", command=lambda root=root: quit(root))
#button.pack(anchor=CENTER)

label9 = Label(root, text="\n\nPrijemnik #3")
label9.pack(in_=left)

frame = Frame(root)
frame.pack()

def quit(root):
    root.destroy()


label10 = Label(root, text="Ulazna snaga [mW]:")
label10.pack(in_=left)

var7 = StringVar()
ent6 = Entry(root, textvariable=var7, width=7)
ent6.pack(in_=left,anchor=CENTER)

label11 = Label(root, text="Izlazna snaga [mW]:")
label11.pack(in_=left)

var8 = StringVar()
ent7 = Entry(root, textvariable=var8, width=7)
ent7.pack(in_=left,anchor=CENTER)

label12 = Label(root, text="Valna duljina [nm]:")
label12.pack(in_=left)

var9 = StringVar()
ent8 = Entry(root, textvariable=var9, width=7)
ent8.pack(in_=left,anchor=CENTER)

label = Label(root)
label.pack()

label13 = Label(root, text="\n\nPrijemnik #4")
label13.pack(in_=left)

frame = Frame(root)
frame.pack()

def quit(root):
    root.destroy()


label14 = Label(root, text="Ulazna snaga [mW]:")
label14.pack(in_=left)

var10 = StringVar()
ent9 = Entry(root, textvariable=var10, width=7)
ent9.pack(in_=left,anchor=CENTER)

label15 = Label(root, text="Izlazna snaga [mW]:")
label15.pack(in_=left)

var11 = StringVar()
ent10 = Entry(root, textvariable=var11, width=7)
ent10.pack(in_=left,anchor=CENTER)

label16 = Label(root, text="Valna duljina [nm]:")
label16.pack(in_=left)

var12 = StringVar()
ent11 = Entry(root, textvariable=var12, width=7)
ent11.pack(in_=left,anchor=CENTER)

label = Label(root)
label.pack()

label112 = Label(root, text="Valna duljina predajnika #1: " + str(lista_svih_valnih_duljina[0])+ "[nm]")
label112.pack(in_=right)

label113 = Label(root, text="Valna duljina predajnika #2: " + str(lista_svih_valnih_duljina[1])+ "[nm]")
label113.pack(in_=right)

label113 = Label(root, text="Valna duljina predajnika #3: " + str(lista_svih_valnih_duljina[2])+ "[nm]")
label113.pack(in_=right)

button = Button(root, text="Dalje", font=('Console', 20),command=lambda root=root: quit(root))
button.pack()

def close(root):
    root.destroy()
    exit()

e = Button(root, text="Exit", font=('Console', 20), command=lambda: close(root))
e.place(rely=0, relx=1.0, x=0, y=0, anchor=NE)

root.mainloop()


izlazna2 = []
ulazna2 = []
valna2 = []



izlazna2.append (int(float(var2.get())))
ulazna2.append( int(float(var.get())))
# self.raspon = input("Raspon podesavanja = ")
# self.vrijeme = input("Vrijeme podesavanja = ")
valna2.append(int(float(var3.get())))

izlazna2.append (int(float(var5.get())))
ulazna2.append( int(float(var4.get())))
# self.raspon = input("Raspon podesavanja = ")
# self.vrijeme = input("Vrijeme podesavanja = ")
valna2.append(int(float(var6.get())))

izlazna2.append (int(float(var8.get())))
ulazna2.append( int(float(var7.get())))
# self.raspon = input("Raspon podesavanja = ")
# self.vrijeme = input("Vrijeme podesavanja = ")
valna2.append(int(float(var9.get())))
#print snage
#print snage

izlazna2.append (int(float(var11.get())))
ulazna2.append( int(float(var10.get())))
# self.raspon = input("Raspon podesavanja = ")
# self.vrijeme = input("Vrijeme podesavanja = ")
valna2.append(int(float(var12.get())))
#print snage
#print snage

for i in range(0, n):
    list_of_Prijemnik_references.append(Prijemnik(i, 0, izlazna2[i], ulazna2[i], valna2[i]))

#demux = DeMux(list_of_Predajnik_references)

snage2 = np.array(snage)
snaga = np.sum(snage2)

print lista_svih_valnih_duljina
valne_prijemnika = []
snage_prijemnika = []
for i in range(0,n):
    valne_prijemnika.append(list_of_Prijemnik_references[i].valna_duljina)
    snage_prijemnika.append(list_of_Prijemnik_references[i].loss)


while True:
    #root = Tk()


    def izaberiMux():
        global var_m_s
        var_m_s = "multiplekser"


    def izaberiS():
        global var_m_s
        var_m_s = "spreznik"


    def quit(root):
        root.destroy()


    def combine_funcs(*funcs):
        def combined_func(*args, **kwargs):
            for f in funcs:
                f(*args, **kwargs)

        return combined_func


    """
    label7 = Label(root, text="Sto zelite dodati")
    label7.pack()

    buttonm = Button(root, text="Multiplekser", command=combine_funcs(izaberiMux, lambda root=root: quit(root)))
    buttonm.pack()

    buttons = Button(root, text="Spreznik", command=combine_funcs(izaberiS, lambda root=root: quit(root)))
    buttons.pack()

    root.mainloop()
    """
    izbor = "multiplekser"
    # print str (izbor)
    # izbor = str(izbor)

    if (izbor == "multiplekser"):
        mux = Mux(list_of_Predajnik_references, lista_svih_valnih_duljina, valne_prijemnika, snage, snage_prijemnika)
        #snage = [x + mux.loss for x in snage]
        snaga = snaga + mux.loss

        break

    elif (izbor == "spreznik"):
        spreznik = Spreznik(list_of_Predajnik_references)
        #snage = [x + spreznik.loss for x in snage]
        snaga = snaga + spreznik.loss
        break
preddefiniran_izbor = ["pojacalo", "filter", "nista", "filter", "valni pretvornik", "nista", "filter", "pojacalo", "pojacalo", "nista", "filter", "nista"]
flag = 0
while True:

    #root = Tk()


    def izaberiPo():
        global var1
        var1 = "pojacalo"


    def izaberiA():
        global var1
        var1 = "addmux"


    def izaberiR():
        global var1
        var1 = "raspreznik"


    def izaberiPr():
        global var1
        var1 = "prospojnik"



    def izaberiD():
        global var1
        var1 = "demux"


    def combine_funcs(*funcs):
        def combined_func(*args, **kwargs):
            for f in funcs:
                f(*args, **kwargs)

        return combined_func


    def quit(root):
        root.destroy()


    """
    label7 = Label(root, text="Sto zelite dodati")
    label7.pack()

    buttonm = Button(root, text="Pojacalo", command=combine_funcs(izaberiPo, lambda root=root: quit(root)))
    buttonm.pack()

    buttons = Button(root, text="Addmux", command=combine_funcs(izaberiA, lambda root=root: quit(root)))
    buttons.pack()

    buttonm = Button(root, text="Raspreznik", command=combine_funcs(izaberiR,  lambda root=root: quit(root)))
    buttonm.pack()

    buttonm = Button(root, text="Prospojnik", command=combine_funcs(izaberiPr, lambda root=root: quit(root)))
    buttonm.pack()

    buttonm = Button(root, text="Demux", command=combine_funcs(izaberiD, lambda root=root: quit(root)))
    buttonm.pack()

    root.mainloop()
    """
    if flag == 0:
        izbor2 = "pojacalo"
    elif flag == 1:
        izbor2 = "raspreznik"

    if izbor2 == "addmux":
        addmux = AddDropMux(lista_svih_valnih_duljina)
        lista_svih_valnih_duljina = addmux.list
        print lista_svih_valnih_duljina
        snaga = snaga + addmux.loss
        continue

    if izbor2 == "pojacalo":
        pojacalo = OptickoPojacalo(1, lista_svih_valnih_duljina, valne_prijemnika, snaga)
        #snage = [x+pojacalo.loss for x in snage]
        snaga = snaga + pojacalo.loss
        #print snage
        flag = 1
        #print snage

        #snage.append(list_of_Predajnik_references[i].loss)
        continue

    if (izbor2 == "demux"):
        demux = DeMux(lista_svih_valnih_duljina, all_signals)
        all_signals = demux.signals
        snage3 = demux.snage
        snage3 = [x+snaga for x in snage3]
        #print all_signals
        for i in range(0, len(all_signals)):
            while True:
                root = Tk()


                def izaberiPo():
                    global var2
                    var2 = "pojacalo"


                def izaberiV():
                    global var2
                    var2 = "valni pretvornik"

                def izaberiN():
                    global var2
                    var2 = "nista"


                def combine_funcs(*funcs):
                    def combined_func(*args, **kwargs):
                        for f in funcs:
                            f(*args, **kwargs)

                    return combined_func


                def quit(root):
                    root.destroy()



                label7 = Label(root, text="Sto zelite dodati")
                label7.pack()

                buttonm = Button(root, text="Pojacalo", command=combine_funcs(izaberiPo, lambda root=root: quit(root)))
                buttonm.pack()

                buttons = Button(root, text="Valni pretvornik", command=combine_funcs(izaberiV, lambda root=root: quit(root)))
                buttons.pack()

                buttons = Button(root, text="nista", command=combine_funcs(izaberiN, lambda root=root: quit(root)))
                buttons.pack()

                root.mainloop()

                izbor3 = var2
                if izbor3 == "pojacalo":
                    pojacalo = OptickoPojacalo()
                    snage3[i] = snage3[i] + pojacalo.loss
                    continue
                if izbor3 == "valni pretvornik":
                    pretvornik = ValniPretvornik()
                    all_signals[i] = pretvornik.nova_valna_duljina
                    snage3[i] = snage3[i] + pretvornik.loss
                    continue
                if izbor3 == "nista":
                    break

        for i in range(0, len(all_signals)):
                    #TODO: dodati slucaj za vise prijemnika od predajnika kada se koristi demux
                    if (list_of_Prijemnik_references[i].valna_duljina == all_signals[i]):
                        print "VALJA"
                        if snage3[i]>list_of_Prijemnik_references[i].loss:
                            print snage3[i]
                            print list_of_Prijemnik_references[i].loss
                            print "dovoljno snage"
                            rezultat = "Primljen signal sa dovoljno snage"
                            root = Tk()


                            def quit(root):
                                root.destroy()


                            label = Label(root, text=rezultat)
                            label.pack()

                            button = Button(root, text="Dalje", command=lambda root=root: quit(root))
                            button.pack()

                            root.mainloop()
                        else:
                            print "nedovoljno snage"
                            print snage3[i]
                            print list_of_Prijemnik_references[i].loss
                            rezultat = "Dobra valna duljina ali nedovoljno snage"
                            root = Tk()


                            def quit(root):
                                root.destroy()


                            label = Label(root, text=rezultat)
                            label.pack()

                            button = Button(root, text="Dalje", command=lambda root=root: quit(root))
                            button.pack()

                            root.mainloop()
                    else:
                        print list_of_Prijemnik_references[i].valna_duljina
                        print all_signals[i]
                        print "nevalja"
                        rezultat = "Signal nije primljen"
                        root = Tk()


                        def quit(root):
                            root.destroy()


                        label = Label(root, text=rezultat)
                        label.pack()

                        button = Button(root, text="Dalje", command=lambda root=root: quit(root))
                        button.pack()

                        root.mainloop()

        break



        #for i in range(0, len(demux.tablica_usmjeravanja)):
        #    if (list_of_Predajnik_references[i].valna_duljina == list_of_Prijemnik_references[demux.tablica_usmjeravanja[i]-1].valna_duljina):
        #        print "VALJA"
        #    else:
        #        print "nevalja"


    if (izbor2 == "raspreznik"):
        raspreznik = Raspreznik(list_of_Predajnik_references, lista_svih_valnih_duljina, lista_svih_valnih_duljina,valne_prijemnika, snaga)
        all_signals = raspreznik.signals
        snage3 = raspreznik.snage
        snage3 = [x + snaga for x in snage3]
        for i in range (0, len(snage3)):
            snage3[i]=float(snage3[i])/float(len(snage3))
        #print all_signals
        ii = 0
        jj = 2
        ff = 1
        for i in range (0, len(all_signals)):
            while True:
                #root = Tk()


                def izaberiPo():
                    global var3
                    var3 = "pojacalo"


                def izaberiAdm():
                    global var3
                    var3 = "addmux"


                def izaberiFil():
                    global var3
                    var3 = "filter"


                def combine_funcs(*funcs):
                    def combined_func(*args, **kwargs):
                        for f in funcs:
                            f(*args, **kwargs)

                    return combined_func


                def quit(root):
                    root.destroy()

                """
                label7 = Label(root, text="Sto zelite dodati")
                label7.pack()

                buttonm = Button(root, text="Pojacalo", command=combine_funcs(izaberiPo, lambda root=root: quit(root)))
                buttonm.pack()

                buttons = Button(root, text="Addmux",
                                 command=combine_funcs(izaberiAdm, lambda root=root: quit(root)))
                buttons.pack()

                buttons = Button(root, text="filter", command=combine_funcs(izaberiFil, lambda root=root: quit(root)))
                buttons.pack()

                root.mainloop()
                """
                izbor2 = preddefiniran_izbor[ii]
                #if izbor2 == "addmux":
                    #addmux = AddDropMux(all_signals)
                    #all_signals = addmux.list
                    #lista_svih_valnih_duljina = addmux.list
                    #continue

                if izbor2 == "addmux":
                    addmux = AddDropMux(lista_svih_valnih_duljina)
                    lista_svih_valnih_duljina = addmux.list
                    print lista_svih_valnih_duljina
                    snaga = snaga + addmux.loss
                    if (len(lista_svih_valnih_duljina) == 1):
                        break
                    else:
                        continue

                if izbor2 == "pojacalo":
                    pojacalo = OptickoPojacalo(jj, all_signals[i], valne_prijemnika, snage3[i])
                    snage3[i] = snage3[i] + pojacalo.loss
                    ii += 1
                    jj += 1
                    continue

                if izbor2 == "filter":
                    filter = Filter(all_signals[i], ff, all_signals[i], valne_prijemnika, snage3[i])
                    if filter.flag2 == 0:
                        continue
                    else:
                        all_signals[i]=filter.izlazna
                        snage3[i] = snage3[i] + filter.loss
                        ii += 1
                        ff += 1
                    break

            while True:

                #root = Tk()


                def izaberiPo():
                    global var4
                    var4 = "pojacalo"


                def izaberiV():
                    global var4
                    var4 = "valni pretvornik"


                def izaberiN():
                    global var4
                    var4 = "nista"


                def combine_funcs(*funcs):
                    def combined_func(*args, **kwargs):
                        for f in funcs:
                            f(*args, **kwargs)

                    return combined_func


                def quit(root):
                    root.destroy()

                """
                label7 = Label(root, text="Sto zelite dodati")
                label7.pack()

                buttonm = Button(root, text="Pojacalo", command=combine_funcs(izaberiPo, lambda root=root: quit(root)))
                buttonm.pack()

                buttons = Button(root, text="Valni pretvornik",
                                 command=combine_funcs(izaberiV, lambda root=root: quit(root)))
                buttons.pack()

                buttons = Button(root, text="nista", command=combine_funcs(izaberiN, lambda root=root: quit(root)))
                buttons.pack()

                root.mainloop()
                """
                izbor3 = preddefiniran_izbor[ii]
                if izbor3 == "pojacalo":
                    pojacalo = OptickoPojacalo(jj, all_signals[i], valne_prijemnika, snage3[i])
                    snage3[i] = snage3[i] + pojacalo.loss
                    ii += 1
                    jj += 1
                    continue
                if izbor3 == "valni pretvornik":
                    pretvornik = ValniPretvornik( all_signals[i], valne_prijemnika, snage3[i])
                    all_signals[i] = pretvornik.nova_valna_duljina
                    snage3[i] = snage3[i] + pretvornik.loss
                    ii += 1
                    continue
                if izbor3 == "nista":
                    ii += 1
                    break

        for i in range(0, len(all_signals)):
            # TODO: dodati slucaj za vise prijemnika od predajnika kada se koristi demux
            if (list_of_Prijemnik_references[i].valna_duljina == all_signals[i]):
                print "VALJA"
                rezultat = "Primljen signal dobre valne duljine"
                if snage3[i] > list_of_Prijemnik_references[i].loss:
                    print snage3[i]
                    print list_of_Prijemnik_references[i].loss
                    print "dovoljno snage"
                    rezultat = rezultat + " sa dovoljno snage"
                    root = Tk()
                    root.attributes("-fullscreen", True)
                    def quit(root):
                        root.destroy()

                    label = Label(root, text=rezultat)
                    label.pack()

                    button = Button(root, text="Dalje", command= lambda root=root:quit(root))
                    button.pack()

                    root.mainloop()
                else:
                    print "nedovoljno snage"
                    print snage3[i]
                    print list_of_Prijemnik_references[i].loss
                    rezultat = "Dobra valna duljina ali nedovoljno snage"
                    root = Tk()
                    root.attributes("-fullscreen", True)

                    def quit(root):
                        root.destroy()

                    label = Label(root, text=rezultat)
                    label.pack()

                    button = Button(root, text="Dalje", command=lambda root=root: quit(root))
                    button.pack()

                    root.mainloop()
            else:
                print list_of_Prijemnik_references[i].valna_duljina
                print all_signals[i]
                print "nevalja"
                rezultat = "Signal nije primljen"
                root = Tk()
                root.attributes("-fullscreen", True)

                def quit(root):
                    root.destroy()

                label = Label(root, text=rezultat)
                label.pack()

                button = Button(root, text="Dalje", command=lambda root=root: quit(root))
                button.pack()



                root.mainloop()
        #for i in range(0, len(all_signals)):
            #if (list_of_Prijemnik_references[i].valna_duljina == all_signals[i]):
                #print "VALJA"
            #else:
                #print list_of_Prijemnik_references[i].valna_duljina
                #print all_signals[i]
                #print "nevalja"

        break

#za demux
#for i in range(0, n):

# mux = Mux(list_of_Predajnik_references)
# print mux.vlakno.broj_WDM_kanala

#print list_of_Predajnik_references[0].vlakno.duljina
#print list_of_Predajnik_references[1].vlakno.duljina

