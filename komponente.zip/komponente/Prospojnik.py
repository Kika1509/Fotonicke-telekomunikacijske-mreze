from Vlakno import Vlakno
from Tkinter import *
from Predajnik import Predajnik


class Prospojnik:

    empCount = 0

    def __init__(self, list, signals):
        self.list = list
        self.signals = signals
        self.gubitak = 5            #konstanta

        self.tablica_usmjeravanja = []

        self.snage = []

        for i in range (0, len(list)):
            #while True:
            root = Tk()

            def quit(root):
                root.destroy()

            label4 = Label(root, text="Prospojnik")
            label4.pack()

            frame = Frame(root)
            frame.pack()

            var = IntVar()

            label = Label(root, text="Unesite izlaz na koji zelite demultipleksirati valnu duljinu " + str(
                list[i].valna_duljina))
            label.pack()

            var1 = StringVar()
            ent = Entry(root, textvariable=var1, width=7)
            ent.pack(anchor=CENTER)

            button = Button(root, text="Dalje", command=lambda root=root: quit(root))
            button.pack(anchor=CENTER)

            root.mainloop()
            self.tablica_usmjeravanja.append(var.get())
            #TODO: dodati provjeru da se vise valnih duljina ne demultipleksira na isto odrediste
            if self.tablica_usmjeravanja[i] < len(signals):
               self.signals[self.tablica_usmjeravanja[i]] = list[i]
            else:
                pass

        for i in range (0, len(list)):
            vlakno = Vlakno()
            self.loss = self.gubitak - vlakno.duljina * vlakno.prigusenje - 2 * vlakno.konektor
            self.snage.append(- self.gubitak - vlakno.duljina * vlakno.prigusenje - 2 * vlakno.konektor)
