from Vlakno import Vlakno
from Tkinter import *
from Predajnik import Predajnik

class AddDropMux:

    def __init__(self, list):
        self.list = list
        # self.signals =

        root = Tk()

        def quit(root):
            root.destroy()

        label4 = Label(root, text="Addmux")
        label4.pack()

        frame = Frame(root)
        frame.pack()



        label = Label(root, text=str(list) +"\nKoju valnu duljinu zelite izbaciti [nm]:")
        label.pack()

        var1 = StringVar()
        ent = Entry(root, textvariable=var1, width=7)
        ent.pack(anchor=CENTER)

        button = Button(root, text="Dalje", command=lambda root=root: quit(root))
        button.pack(anchor=CENTER)

        root.mainloop()

        self.odbacena = int(float(var1.get()))
        self.gubitak = 3                        #neka bude gubitak ove komponente konstanta
        if self.odbacena in self.list:
            self.list.remove(self.odbacena)
        else:
            pass

        vlakno = Vlakno()
        self.loss = -self.gubitak - vlakno.duljina * vlakno.prigusenje - 2 * vlakno.konektor