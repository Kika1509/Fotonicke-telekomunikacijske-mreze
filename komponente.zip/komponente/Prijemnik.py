from Vlakno import Vlakno
from Tkinter import *
import math


class Prijemnik:

   def __init__(self, redni_broj, flag, izlazna, ulazna, valna):
          self.redni_broj = redni_broj
          if flag == 1:
                 root = Tk()

                 def quit(root):
                        root.destroy()

                 label4 = Label(root, text=" Prijamnik " + str(self.redni_broj + 1))
                 label4.pack()

                 frame = Frame(root)
                 frame.pack()


                 label = Label(root, text="Ulazna snaga [mW]:")
                 label.pack()

                 var = StringVar()
                 ent = Entry(root, textvariable=var, width=7)
                 ent.pack(anchor=CENTER)

                 label2 = Label(root, text="Izlazna snaga [mW]:")
                 label2.pack()

                 var2 = StringVar()
                 ent1 = Entry(root, textvariable=var2, width=7)
                 ent1.pack(anchor=CENTER)

                 label3 = Label(root, text="Valna duljina [nm]:")
                 label3.pack()

                 var3= StringVar()
                 ent3 = Entry(root, textvariable=var3, width=7)
                 ent3.pack(anchor=CENTER)

                 label4 = Label(root, text="Minimalna osjetljivost [dB]:")
                 label4.pack()

                 var4 = StringVar()
                 ent2 = Entry(root, textvariable=var4, width=7)
                 ent2.pack(anchor=CENTER)

                 label = Label(root)
                 label.pack()

                 button = Button(root, text="Dalje", command=lambda root=root: quit(root))
                 button.pack(anchor=CENTER)

                 root.mainloop()



                 self.izlazna_snaga = int(float(var2.get()))
                 self.ulazna_snaga = int(float(var.get()))
                 #self.raspon = input("Raspon podesavanja = ")
                 #self.vrijeme = input("Vrijeme podesavanja = ")
                 self.valna_duljina = int(float(var3.get()))
                 print
          else:
                 self.izlazna_snaga = izlazna
                 self.ulazna_snaga = ulazna
                 # self.raspon = input("Raspon podesavanja = ")
                 # self.vrijeme = input("Vrijeme podesavanja = ")
                 self.valna_duljina = valna
          self.loss = 10 * math.log10(float(self.izlazna_snaga) / float(self.ulazna_snaga))

