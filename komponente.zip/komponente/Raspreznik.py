from Vlakno import Vlakno
from Tkinter import *
from PIL import ImageTk, Image

#napomena: raspreznik odvaja signal na onoliko dijelova koliko ima prijemnika!
#mogucnost: definirati broj raspregnutih grana pa kasnije demultipleksirati?

class Raspreznik:
   def __init__(self, list, signals, list2, list3, snaga):
        self.signals = signals

        root = Tk()
        left = Frame(root)
        right = Frame(root)
        right.pack(side=RIGHT)
        left.pack(side=LEFT)
        root.attributes("-fullscreen", True)

        def quit(root):
            root.destroy()

        left1 = Frame(root)
        left1.pack(side=LEFT)
        bottom = Frame(root)

        bottom.pack(side=BOTTOM)
        img = ImageTk.PhotoImage(Image.open("src/splitter.jpg"))
        panel = Label(root, image=img)
        panel.pack(fill="both", expand="yes")

        label4 = Label(root, text="Raspreznik")
        label4.pack(in_=left)

        label = Label(root, text="Gubitak [dB]:")
        label.pack(in_=left)

        var1 = StringVar()
        ent = Entry(root, textvariable=var1, width=7)
        ent.pack(in_=left, anchor=CENTER)
        button = Button(root, text="Dalje", command=lambda root=root: quit(root))
        button.pack(in_=left)

        broj = ""
        if isinstance(list2, int):
             broj = "\n" + str(list2) + "[nm]"
        else:
             for i in range(0, len(list2)):
                  broj += "\n" + str(list2[i]) + "[nm]"

        broj2 = ""
        if isinstance(list3, int):
             broj2 = "\n" + str(list3) + "[nm]"
        else:
             for i in range(0, len(list3)):
                  broj2 += "\n" + str(list3[i]) + "[nm]"

        label8 = Label(root, text="Valne duljine na ulazu u pojacalo:" + broj)
        label8.pack(in_=right)

        label8 = Label(root, text="\nValne duljine prijemnika:" + broj2)
        label8.pack(in_=right)

        label8 = Label(root, text="\nUlazna snaga:" + str(snaga) +"[dB]")
        label8.pack(in_=right)

        root.mainloop()


        #self.gubitak_sprezanja = input("Gubitak sprezanja = ")
        self.gubitak_rasprezanja = float(var1.get())
        #self.omjer_rasprezanja = input("Omjer rasprezanja = ")
        #self.uneseni_gubici = input("Uneseni gubici = ")
        #self.usmjerenost = input("Usmjerenost = ")
        self.lista_izlaznih_vlakna = []
        temp = []
        self.snage = []
        print
        #self.vlakno = Vlakno (1, input("Unesite duljinu vlakna od predajnika " + str(redni_broj) + " do multipleksera: "))
        for i in range(0, len(list)):
            self.lista_izlaznih_vlakna.append(Vlakno())
            temp.append(list[i].valna_duljina)
        for j in range(0, len(signals)):
            signals[j]=temp
            vlakno = Vlakno()
            self.snage.append(- self.gubitak_rasprezanja - vlakno.duljina * vlakno.prigusenje - 2 * vlakno.konektor)
