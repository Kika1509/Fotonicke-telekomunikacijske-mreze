from Vlakno import Vlakno
from Tkinter import *

class Spreznik:
   def __init__(self, list):

        root = Tk()

        def quit(root):
             root.destroy()


        var2 = IntVar()


        label1 = Label(root, text="Spreznik")
        label1.pack()

        label1 = Label(root, text="Gubitak sprezanja [dB]")
        label1.pack()

        var1 = StringVar()
        ent = Entry(root, textvariable=var1, width=7)
        ent.pack(anchor=CENTER)

        #label2 = Label(root, text="Usmjerenost")
        #label2.pack()

        #scale2 = Scale(root, orient=HORIZONTAL, variable=var2)
        #scale2.pack()

        button2 = Button(root, text="Dalje", command=lambda root=root: quit(root))
        button2.pack(anchor=CENTER)

        root.mainloop()


        self.gubitak_sprezanja = int(float(var1.get()))
        #self.gubitak_rasprezanja = input("Gubitak rasprezanja = ")
        #self.omjer_rasprezanja = input("Omjer rasprezanja = ")
        #self.uneseni_gubici = input("Uneseni gubici = ")
        self.usmjerenost = var2.get()

        vlakno = Vlakno()
        self.loss = - self.gubitak_sprezanja - vlakno.duljina * vlakno.prigusenje - 2 * vlakno.konektor
